# Orbit Android source — v1.2.0

এই ZIP-এ v1.2.0 source revision-এর পরিবর্তন:
- Android app versionCode 3 / versionName 1.2.0।
- অফিসের GPS coordinates/radius বদলালে আগের geofence registration সরিয়ে নতুন registration যোগ করার ব্যবস্থা।
- Geofence receiver-এ একই transition-এর ২ মিনিটের duplicate callback filter।
- App বন্ধ থাকা অবস্থায় জমা হওয়া geofence event queue সর্বোচ্চ ১০০টি event-এ সীমাবদ্ধ।
- GitHub Actions artifact-এর নাম Orbit-v1.2.0-debug-apk করা হয়েছে।

গুরুত্বপূর্ণ যাচাই:
- এই প্যাকেজটি source ZIP; APK নয়।
- এই পরিবেশে Android SDK/Gradle build চালিয়ে APK compile বা বাস্তব ফোনে পরীক্ষা করা হয়নি।
- Android 10+ এ Background Location-এর “Allow all the time”, Android 13+ এ notification permission এবং Android 12+ এ exact-alarm access আলাদাভাবে অনুমোদন করতে হতে পারে।
- Geofence delivery ফোনের Android version, Google Play services, battery restrictions এবং location settings-এর ওপর নির্ভর করে।
- Email bridge ইমেল অ্যাপের draft/chooser খোলে; নিজে থেকে ইমেল পাঠায় না।
