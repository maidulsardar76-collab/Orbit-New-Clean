package com.orbit.attendance

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import org.json.JSONArray
import org.json.JSONObject

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return

        val kind = when (event.geofenceTransition) {
            Geofence.GEOFENCE_TRANSITION_ENTER -> "in"
            Geofence.GEOFENCE_TRANSITION_EXIT -> "out"
            else -> return
        }

        val prefs = context.getSharedPreferences("orbit_native", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val arr = try {
            JSONArray(prefs.getString("pending_punches", "[]"))
        } catch (_: Exception) {
            JSONArray()
        }

        // Android may deliver repeated transition callbacks. Ignore the same event
        // if it was already queued in the last two minutes.
        for (i in arr.length() - 1 downTo 0) {
            val previous = arr.optJSONObject(i) ?: continue
            if (now - previous.optLong("timestamp") > 2 * 60 * 1000L) break
            if (previous.optString("kind") == kind) return
        }

        arr.put(JSONObject().put("kind", kind).put("timestamp", now))
        // Keep the queue bounded if the app stays closed for a long time.
        val bounded = JSONArray()
        val first = (arr.length() - 100).coerceAtLeast(0)
        for (i in first until arr.length()) bounded.put(arr.get(i))
        prefs.edit().putString("pending_punches", bounded.toString()).apply()
    }
}
